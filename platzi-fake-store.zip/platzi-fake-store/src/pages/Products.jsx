
export default function Products(){
    return(
        <h1 className="text-2xl font-bold">DATA PRODUK</h1>
    )
}